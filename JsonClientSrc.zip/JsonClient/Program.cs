﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Collections.Generic;
using System.Threading;
using NetLib;
using Newtonsoft.Json;

namespace JsonClient
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;

            int port = 8060;
            string ip_address = "127.0.0.1";

            IPAddress ip = IPAddress.Parse(ip_address);

            IPEndPoint endPoint = new IPEndPoint(ip, port);

            Socket socket = new Socket(AddressFamily.InterNetwork,
                SocketType.Stream, ProtocolType.Tcp);

            socket.Connect(endPoint);

            Console.WriteLine("[CLIENT] Подключение прошло успешно!");

            Thread thread_reseive = new Thread(GetMessageFromServer);


            while (true)
            {
                // отправка сообщений
                Console.WriteLine("Введите ваш запрос:");
                string message = Console.ReadLine();

                // проверка правильности запроса
                bool resultId = message.StartsWith("id=");
                bool resultName = message.StartsWith("name=");
                bool resultAge = message.StartsWith("age=");
                bool resultPhone = message.StartsWith("phone=");
                bool resultSpace = message.Contains(" ");

                if ((resultId || resultName || resultAge || resultPhone) && !resultSpace) NetLib.NetLib.SendDataToNet(socket, message);
                else
                {
                    Console.WriteLine("Ошибка в записи запроса! Пример запроса: name=Петя");
                    continue;
                }
                thread_reseive.Start(socket);
            }

            Console.ReadLine();
        }
        static void GetMessageFromServer(object obj)
        {
            Socket socket = (Socket)obj;

            while (true)
            {
                Query query = JsonConvert.DeserializeObject<Query>(NetLib.NetLib.ReadDataFromNet(socket));  // Десериализацтя запроса
                Console.WriteLine($"id: {query.Id}, name: {query.Name}, age: {query.Age}, phone: {query.Phone}");
            }
        }
    }
    class Query
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public string Phone { get; set; }
    }
}