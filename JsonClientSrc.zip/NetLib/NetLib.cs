﻿using System;
using System.Net.Sockets;
using System.Text;

namespace NetLib
{
    public class NetLib
    {
        /// <summary>
        /// Отправка данных (текста) по сети
        /// </summary>
        /// <param name="socket"></param>
        /// <param name="text"></param>
        public static void SendDataToNet(Socket socket, string text)
        {
            byte[] text_bytes = Encoding.Unicode.GetBytes(text);
            socket.Send(text_bytes);
        }

        /// <summary>
        /// Прием данных по сети
        /// </summary>
        /// <param name="socket"></param>
        /// <returns></returns>
        public static string ReadDataFromNet(Socket socket)
        {
            byte[] data = new byte[256];  // буфер для приема
            int num_bytes = socket.Receive(data);
            return Encoding.Unicode.GetString(data, 0, num_bytes);
        }
    }
}