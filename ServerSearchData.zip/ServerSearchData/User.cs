﻿
namespace ServerSearchData
{
    /// <summary>
    /// User class (template)
    /// </summary>
    class User
    {
        int id;
        string name;
        int age;
        string phone;

        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public int Age
        {
            get { return age; }
            set { age = value; }
        }

        public string Phone
        {
            get { return phone; }
            set { phone = value; }
        }
    }
}
