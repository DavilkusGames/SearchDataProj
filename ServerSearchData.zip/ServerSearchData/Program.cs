﻿// ================== LIBRARIES ========================
using Newtonsoft.Json; // Json library
using System;
using System.Collections.Generic;
using System.Threading;
using System.Net;
using System.Net.Sockets;
// =====================================================

/// <summary>
/// Server
/// </summary>
namespace ServerSearchData
{
    /// <summary>
    /// Main class
    /// </summary>
    class Program
    {
        static NetHelper netHelper = new NetHelper(); // Net helper
        static JsonHelper jsonHelper = new JsonHelper(); // Json helper
        static List<string> usersJson = new List<string>(); // List of users in json format

        // ========== SERVER SETTINGS ===============
        static string ip_address = "127.0.0.1";     // Ip of the server
        static int port = 8080;                     // Port of the server
        static int maxUsers = 30;                   // max users
        // ==========================================

        /// <summary>
        /// Main
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            Console.Title = "Server";

            usersJson = jsonHelper.ReadData(); // Read json file
            if (usersJson == null)
            {
                Console.WriteLine("[SERVER] ERROR READING FILE");
                Console.ReadLine();
                return;
            }
            Console.WriteLine("[SERVER] Data readed");

            Console.Write("[SERVER] Enter ip: ");
            ip_address = Console.ReadLine();
            Console.Write("[SERVER] Enter port: ");
            try { port = int.Parse(Console.ReadLine()); }
            catch { Console.WriteLine("[SERVER] Port must be INT!"); Console.ReadLine(); return; }

            IPAddress ip;
            try { ip = IPAddress.Parse(ip_address); } // Parsing ip
            catch { Console.WriteLine("[SERVER] Wrong ip"); Console.ReadLine(); return; }

            Socket serverSocket;
            IPEndPoint endPoint;
            try
            {
                endPoint = new IPEndPoint(ip, port);

                serverSocket = new Socket(AddressFamily.InterNetwork,
                    SocketType.Stream, ProtocolType.Tcp);

                serverSocket.Bind(endPoint);

                serverSocket.Listen(maxUsers); // Set max users
            }
            catch { Console.WriteLine("[SERVER] Cannot run server!"); Console.ReadLine(); return; }

            Console.WriteLine("[SERVER] Server started");
            int usersConnected = 0; // User counter
            while (true)
            {
                if (usersConnected < maxUsers)
                {
                    Socket clientSocket = serverSocket.Accept();     // Accepting new client (stopping thread)
                    Console.WriteLine("[SERVER] User connected");
                    usersConnected++;
                    Console.Title = "Server; USERS CONNECTED: " + usersConnected.ToString() + "/" + maxUsers.ToString();
                    if (usersConnected >= maxUsers) Console.WriteLine("[SERVER] MAX USERS COUNT REACHED");

                    Thread thread = new Thread(FromClient); // Delegate work with the client to another thread
                    thread.Start(clientSocket);
                }
                else Thread.Sleep(1000);  // If max users earned
            }
        }

        /// <summary>
        /// Working with client
        /// </summary>
        /// <param name="obj"></param>
        static void FromClient(object obj)
        {
            Socket clientSocket = (Socket)obj;

            while (true)
            {
                string request = netHelper.ReadData(clientSocket);      // Reading key request
                List<string> users = SearchUsers(clientSocket, request);       // Searching correct users
                for (int i = 0; i < users.Count; i++) netHelper.SendData(clientSocket, users[i]);     // Sending answer to client
                Console.WriteLine("Sended " + users.Count.ToString() + " answers");
            }
        }

        /// <summary>
        /// Searching users from data
        /// </summary>
        /// <param name="clientSocket"></param>
        /// <param name="request"></param>
        /// <returns></returns>
        static List<string> SearchUsers(Socket clientSocket, string request)
        {
            string[] splitRequest = request.Split('=');          // Splitting request
            string[] keys = { "id", "name", "age", "phone" };    // Available keys of 'User' class

            List<string> users = new List<string>();             // List of correct users

            if (splitRequest.Length != 2) { netHelper.SendData(clientSocket, "E=INVALID INPUT FORMAT"); return users; }     // If incorrect request
            int indReq = jsonHelper.IsContains(keys, splitRequest[0]);      // Check key id
            if (indReq == -1) { netHelper.SendData(clientSocket, "E=INVALID KEY"); return users; }    // If request key is missing
            for (int i = 0; i < usersJson.Count; i++)          // CHECKING EACH USER IN 'DATA'
            {
                string userJson = usersJson[i];
                User user = JsonConvert.DeserializeObject<User>(userJson);     // Deserializing json format to 'User' class
                if (indReq == 0 && user.Id.ToString() == splitRequest[1])       users.Add(userJson);  // Search by 'id'
                else if (indReq == 1 && user.Name == splitRequest[1])           users.Add(userJson);  // Search by 'name'
                else if (indReq == 2 && user.Age.ToString() == splitRequest[1]) users.Add(userJson);  // Search by 'age'
                else if (indReq == 3 && user.Phone == splitRequest[1])          users.Add(userJson);  // Search by 'phone'
            }
            return users;
        }
    }
}