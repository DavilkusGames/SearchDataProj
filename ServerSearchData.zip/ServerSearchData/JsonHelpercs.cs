﻿using System;
using System.Collections.Generic;
using System.IO;

namespace ServerSearchData
{
    /// <summary>
    /// Json tools and more
    /// </summary>
    class JsonHelper
    {
        /// <summary>
        /// Read user data from .json file
        /// </summary>
        /// <returns></returns>
        public List<string> ReadData()
        {
            List<string> usersJson = new List<string>();
            try
            {
                string path = Environment.CurrentDirectory + "/data.json";
                using (StreamReader reader = new StreamReader(path))
                {
                    usersJson.Add(reader.ReadToEnd());
                }
            }
            catch
            {
                return null;
            }
            return usersJson;
        }
        /// <summary>
        /// Return index of the key (-1 if it's missing)
        /// </summary>
        /// <param name="array"></param>
        /// <param name="key"></param>
        /// <returns></returns>
        public int IsContains(string[] array, string key)
        {
            int ind = -1;
            for (int i = 0; i < array.Length; i++)
            {
                if (array[i] == key) { ind = i; break; }
            }
            return ind;
        }
    }
}
