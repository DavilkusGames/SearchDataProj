﻿using System;
using System.Collections.Generic;
using System.IO;

namespace ServerSearchData
{
    /// <summary>
    /// Json tools and more
    /// </summary>
    class JsonHelper
    {
        /// <summary>
        /// Read user data from .json file
        /// </summary>
        /// <returns></returns>
        public List<string> ReadData()
        {
            List<string> usersJson = new List<string>();
            try
            {
                string path = Environment.CurrentDirectory + "/data.json";
                StreamReader reader;
                using (reader = new StreamReader(path))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                        usersJson.Add(line);
                }
                reader.Close();
            }
            catch
            {
                return null;
            }
            return usersJson;
        }
        /// <summary>
        /// Return index of the key (-1 if it's missing)
        /// </summary>
        /// <param name="array"></param>
        /// <param name="key"></param>
        /// <returns></returns>
        public int IsContains(string[] array, string key)
        {
            int ind = -1;
            for (int i = 0; i < array.Length; i++)
            {
                if (array[i] == key) { ind = i; break; }
            }
            return ind;
        }
    }
}
