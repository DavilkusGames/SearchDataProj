﻿using System.Text;
using System.Net.Sockets;

namespace ServerSearchData
{
    /// <summary>
    /// Socket Actions
    /// </summary>
    class NetHelper
    {
        /// <summary>
        /// Send Data to client
        /// </summary>
        /// <param name="socket"></param>
        /// <param name="text"></param>
        public void SendData(Socket socket, string text)
        {
            byte[] text_bytes = Encoding.Unicode.GetBytes(text);
            socket.Send(text_bytes);
        }

        /// <summary>
        /// Read Data from client
        /// </summary>
        /// <param name="socket"></param>
        /// <returns></returns>
        public string ReadData(Socket socket)
        {
            byte[] data = new byte[256];
            int num_bytes = socket.Receive(data);
            return Encoding.Unicode.GetString(data, 0, num_bytes);
        }
    }
}
